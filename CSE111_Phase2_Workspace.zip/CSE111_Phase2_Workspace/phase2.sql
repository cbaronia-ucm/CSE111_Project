/*
-- Drop Tables
-- =================================================
DROP TABLE player;
DROP TABLE character;
DROP TABLE playercharacter;
DROP TABLE equipment;
DROP TABLE inventory;
DROP TABLE item;
DROP TABLE inventoryitem;
DROP TABLE weapon;
DROP TABLE armor;
DROP TABLE accessory;
DROP TABLE consumable;
DROP TABLE shop;
DROP TABLE shopitem;

-- =================================================
-- *************************************************
-- =================================================
*/


-- Create Tables
-- =================================================
CREATE TABLE player (
	p_username varchar(255) not null,
	p_password varchar(255) not null
);

CREATE TABLE character (
	c_charname varchar(255) not null,
	c_level int(255) not null,
	c_gold int(255) not null,
	c_str int(255) not null,
	c_vit int(255) not null,
	c_hp int(255) not null
);

CREATE TABLE playercharacter (
	pc_username varchar(255) not null,
	pc_charname varchar(255) not null
);

CREATE TABLE equipment (
	e_charname varchar(255) not null,
	e_weaponkey int(255) not null,
	e_armorkey int(255) not null,
	e_accessorykey int(255) not null,
	e_consumablekey int(255) not null
);

CREATE TABLE inventory (
	invt_charname varchar(255) not null,
	invt_size int(255) not null
);

CREATE TABLE item (
	i_itemkey int(255) not null,
	i_name varchar(255) not null,
	i_desc varchar(255) not null
);

CREATE TABLE inventoryitem (
	invti_charname varchar(255) not null,
	invti_itemkey int(255) not null,
	invti_quantity int(255) not null
);

CREATE TABLE weapon (
	w_weaponkey int(255) not null,
	w_atk int(255) not null
);

CREATE TABLE armor (
	a_armorkey int(255) not null,
	a_def int(255) not null
);

CREATE TABLE accessory (
	accs_accessorykey int(255) not null,
	accs_stat varchar(255) not null,
	accs_rating int(255) not null
);

CREATE TABLE consumable (
	cns_consumablekey int(255) not null,
	cns_stat varchar(255) not null,
	cns_rating int(255) not null
);

CREATE TABLE shop (
	s_charname varchar(255) not null,
	s_size int(255) not null
);

CREATE TABLE shopitem (
	si_charname varchar(255) not null,
	si_itemkey int(255) not null,
	si_quantity int(255) not null,
	si_buy int(255) not null,
	si_sell int(255) not null
);


-- =================================================
-- *************************************************
-- =================================================


-- Insert Sample Data
-- =================================================

-- Player
-- ------------------------------------------
INSERT INTO player VALUES ('user1', '123');
INSERT INTO player VALUES ('user2', '789');
INSERT INTO player VALUES ('user3', '246');
INSERT INTO player VALUES ('user4', '135');
INSERT INTO player VALUES ('user5', 'password');
INSERT INTO player VALUES ('user6', 'birthday');
INSERT INTO player VALUES ('user7', '0000');
INSERT INTO player VALUES ('user8', '833');

-- Character
-- ------------------------------------------
INSERT INTO character VALUES ('Ezio', 3, 256, 5, 5, 75);
INSERT INTO character VALUES ('Dante', 99, 5, 20, 25, 100);
INSERT INTO character VALUES ('Cloud', 50, 2349, 17, 20, 50);
INSERT INTO character VALUES ('Snake', 35, 90, 13, 15, 33);
INSERT INTO character VALUES ('Sora', 3, 256, 5, 5, 75);
INSERT INTO character VALUES ('Joker', 99, 5, 20, 25, 100);
INSERT INTO character VALUES ('Tidus', 50, 2349, 17, 20, 50);
INSERT INTO character VALUES ('Leon', 35, 90, 13, 15, 33);

-- Playercharacter
-- ------------------------------------------
INSERT INTO playercharacter VALUES ('user1', 'Ezio');
INSERT INTO playercharacter VALUES ('user2', 'Dante');
INSERT INTO playercharacter VALUES ('user3', 'Cloud');
INSERT INTO playercharacter VALUES ('user4', 'Snake');
INSERT INTO playercharacter VALUES ('user5', 'Sora');
INSERT INTO playercharacter VALUES ('user6', 'Joker');
INSERT INTO playercharacter VALUES ('user7', 'Tidus');
INSERT INTO playercharacter VALUES ('user8', 'Leon');

-- Equipment
-- ------------------------------------------
INSERT INTO equipment VALUES ('Ezio', 1, 26, 51, 76);
INSERT INTO equipment VALUES ('Cloud', 3, 27, 53, 77);
INSERT INTO equipment VALUES ('Tidus', 2, 28, 52, 78);

-- Inventory
-- ------------------------------------------
INSERT INTO inventory VALUES ('Ezio', 20);
INSERT INTO inventory VALUES ('Cloud', 30);
INSERT INTO inventory VALUES ('Tidus', 25);

-- Item
-- ------------------------------------------
INSERT INTO item VALUES
	(1, 'hidden blade', 'Does this thing'),
	(2, 'long sword', 'Forged here'),
	(3, 'claymore', 'Part of this battle'),

	(26, 'linen clothes', 'Comes from here'),
	(27, 'iron set', 'Crafted by this person'),
	(28, 'mythril chain', 'Does this thing'),

	(51, 'red ring', 'Additional info'),
	(52, 'gold ring of blah', 'Does this thing'),
	(53, 'diamond bangle', 'Does this thing'),

	(76, 'small bandage', 'More info'),
	(77, 'potion', 'Does this thing'),
	(78, 'enhancing powder', 'Does this thing');

-- Inventoryitem
-- ------------------------------------------
INSERT INTO inventoryitem VALUES
	('Ezio', 1, 1),
	('Ezio', 2, 1),

	('Ezio', 26, 1),
	('Ezio', 27, 1),

	('Ezio', 51, 1),
	('Ezio', 52, 1),

	('Ezio', 76, 3),
	('Ezio', 77, 3);
INSERT INTO inventoryitem VALUES
	('Cloud', 3, 1),
	('Cloud', 27, 1),
	('Cloud', 53, 1),
	('Cloud', 77, 5);
INSERT INTO inventoryitem VALUES
	('Tidus', 2, 1),
	('Tidus', 28, 1),
	('Tidus', 52, 1),
	('Tidus', 78, 8);

-- Weapon
-- ------------------------------------------
INSERT INTO weapon VALUES 
	(1, 1),
	(2, 4),
	(3, 10);

-- Weapon
-- ------------------------------------------
INSERT INTO armor VALUES 
	(26, 11),
	(27, 16),
	(28, 21);

-- Weapon
-- ------------------------------------------
INSERT INTO accessory VALUES 
	(51, 'str', 3),
	(52, 'str', 6),
	(53, 'vit', 10);

-- Weapon
-- ------------------------------------------
INSERT INTO consumable VALUES 
	(76, 'vit', 1),
	(77, 'hp', 25),
	(78, 'str', 4);

-- Shop
-- ------------------------------------------
INSERT INTO shop VALUES 
	('Ezio', 30);

-- Shopitem
-- ------------------------------------------
INSERT INTO shopitem VALUES
	('Ezio', 1, 1, 30, 10),
	('Ezio', 26, 1, 25, 8),
	('Ezio', 51, 1, 20, 15),
	('Ezio', 76, 10, 5, 1);

-- =================================================
-- *************************************************
-- =================================================


-- Use Case Examples
-- =================================================

-- Retrieve user's character list
-- -------------------------------------------------
SELECT c_charname, c_level
FROM playercharacter, character
WHERE 
	pc_username = 'user1' AND 
	pc_charname = c_charname
ORDER BY c_level DESC;

/*
-- Delete an existing character for a given user
-- -------------------------------------------------
DELETE 
FROM playercharacter
WHERE pc_username = 'user1'
AND pc_charname = 'Ezio';
*/

-- Check if other users access this character
SELECT pc_username
FROM playercharacter
WHERE 
	pc_charname = 'Ezio';

/*
DELETE 
FROM character
WHERE c_charname = 'Ezio';
*/

/*
-- Delete user account (save user's character list, delete user, then check for unused characters)
-- -------------------------------------------------
DELETE 
FROM playercharacter
WHERE pc_username = 'user1';
*/


-- View Status
-- -------------------------------------------------
SELECT *
FROM character
WHERE 
	c_charname = 'Ezio';

-- View Equipment 
-- -------------------------------------------------
SELECT i_name as weaponName, w_atk as atkPower
FROM character, equipment, item, weapon
WHERE
	c_charname = 'Ezio' AND
	c_charname = e_charname AND
	e_weaponkey = i_itemkey AND
	i_itemkey = w_weaponkey;

SELECT i_name as armorName, a_def as defProtection
FROM character, equipment, item, armor
WHERE
	c_charname = 'Ezio' AND
	c_charname = e_charname AND
	e_armorkey = i_itemkey AND
	e_armorkey = a_armorkey;

SELECT i_name as accessoryName, accs_stat as boostedStat, accs_rating as statIncrease
FROM character, equipment, item, accessory
WHERE
	c_charname = 'Ezio' AND
	c_charname = e_charname AND
	e_accessorykey = i_itemkey AND
	e_accessorykey = accs_accessorykey;

SELECT i_name as consumableName, cns_stat as affectedStat, cns_rating as amountIncrease
FROM character, equipment, item, consumable
WHERE
	c_charname = 'Ezio' AND
	c_charname = e_charname AND
	e_consumablekey = i_itemkey AND 
	e_consumablekey = cns_consumablekey;

-- View Inventory (Display Item Names & Quantity)
-- -------------------------------------------------
SELECT i_name, invti_quantity
FROM
	inventory,
	inventoryitem,
	item
WHERE
	invt_charname = 'Ezio' AND
	invt_charname = invti_charname AND
	invti_itemkey = i_itemkey;

-- Filter for weapons
SELECT i_name, invti_quantity
FROM
	inventory,
	inventoryitem,
	item,
	weapon
WHERE
	invt_charname = 'Ezio' AND
	invt_charname = invti_charname AND
	invti_itemkey = i_itemkey AND
	i_itemkey = w_weaponkey;

-- Filter for armor
SELECT i_name, invti_quantity
FROM
	inventory,
	inventoryitem,
	item,
	armor
WHERE
	invt_charname = 'Ezio' AND
	invt_charname = invti_charname AND
	invti_itemkey = i_itemkey AND
	i_itemkey = a_armorkey;

-- Filter for accessories
SELECT i_name, invti_quantity
FROM
	inventory,
	inventoryitem,
	item,
	accessory
WHERE
	invt_charname = 'Ezio' AND
	invt_charname = invti_charname AND
	invti_itemkey = i_itemkey AND
	i_itemkey = accs_accessorykey;

-- Filter for consumables
SELECT i_name, invti_quantity
FROM
	inventory,
	inventoryitem,
	item,
	consumable
WHERE
	invt_charname = 'Ezio' AND
	invt_charname = invti_charname AND
	invti_itemkey = i_itemkey AND
	i_itemkey = cns_consumablekey;

-- View Shop (Display Item Names, Quantity)
-- -------------------------------------------------
SELECT i_name, si_quantity
FROM
	shop,
	shopitem,
	item
WHERE
	s_charname = 'Ezio' AND
	s_charname = si_charname AND
	si_itemkey = i_itemkey;

-- Filter for weapon
SELECT i_name, si_quantity
FROM
	shop,
	shopitem,
	item,
	weapon
WHERE
	s_charname = 'Ezio' AND
	s_charname = si_charname AND
	si_itemkey = i_itemkey AND
	i_itemkey = w_weaponkey;
	
-- Filter for armor
SELECT i_name, si_quantity
FROM
	shop,
	shopitem,
	item,
	armor
WHERE
	s_charname = 'Ezio' AND
	s_charname = si_charname AND
	si_itemkey = i_itemkey AND
	i_itemkey = a_armorkey;
	
-- Filter for accessory
SELECT i_name, si_quantity
FROM
	shop,
	shopitem,
	item,
	accessory
WHERE
	s_charname = 'Ezio' AND
	s_charname = si_charname AND
	si_itemkey = i_itemkey AND
	i_itemkey = accs_accessorykey;
	
-- Filter for consumable
SELECT i_name, si_quantity
FROM
	shop,
	shopitem,
	item,
	consumable
WHERE
	s_charname = 'Ezio' AND
	s_charname = si_charname AND
	si_itemkey = i_itemkey AND
	i_itemkey = cns_consumablekey;

-- Equip Item (Check if item in inventory, update equipment if so)
-- -------------------------------------------------
UPDATE equipment
SET e_weaponkey = 2
WHERE
	e_charname = 'Ezio';

UPDATE equipment
SET e_armorkey = 27
WHERE
	e_charname = 'Ezio';

UPDATE equipment
SET e_accessorykey = 52
WHERE
	e_charname = 'Ezio';

UPDATE equipment
SET e_consumablekey = 77
WHERE
	e_charname = 'Ezio';

-- Use Item (Check item in inventory, update status, reduce/remove from inventory)
-- -------------------------------------------------
UPDATE character
SET c_hp = 100
WHERE
	c_charname = 'Ezio';
UPDATE inventoryitem
SET invti_quantity = 2
WHERE
	invti_charname = 'Ezio' AND
	invti_itemkey = 77;

-- Buy Item (Check space in inventory, update inventory)
-- Sell Item (Check item in inventory, update status & inventory, reduce/remove from inventory)
-- -------------------------------------------------
-- Ezio bought two potions
UPDATE shopitem
SET si_quantity = 8
WHERE
	si_charname = 'Ezio' AND
	si_itemkey = 76;
UPDATE inventoryitem
SET invti_quantity = 5
WHERE
	invti_charname = 'Ezio' AND
	invti_itemkey = 76;
UPDATE character
SET c_gold = 246
WHERE
	c_charname = 'Ezio';

-- Ezio sells back the two potions
UPDATE shopitem
SET si_quantity = 10
WHERE
	si_charname = 'Ezio' AND
	si_itemkey = 76;
UPDATE inventoryitem
SET invti_quantity = 3
WHERE
	invti_charname = 'Ezio' AND
	invti_itemkey = 76;
UPDATE character
SET c_gold = 248
WHERE
	c_charname = 'Ezio';

-- List items (e.g. to randomly generate rewards)
-- Filter by type (weapon, armor, accessory, consumable)
-- -------------------------------------------------
SELECT *
FROM item, weapon
WHERE 
	i_itemkey = w_weaponkey;

SELECT *
FROM item, armor
WHERE 
	i_itemkey = a_armorkey;

SELECT *
FROM item, accessory
WHERE 
	i_itemkey = accs_accessorykey;

SELECT *
FROM item, consumable
WHERE 
	i_itemkey = cns_consumablekey;

-- =================================================
-- *************************************************
-- =================================================
