import sqlite3
import random

from queries import *

"""
	Displays user login prompt and authenticates input.
	Creates a new account if needed.
	Returns username string
"""
def loginPhase(conn):
	while True:
		username = input("Enter username: ")
        
		if checkUser(conn, username):
			password = input("Username '" + username + "' found\nEnter password: ")
		else:
			password = input("Creating new account for '" + username + "'\nSet new password: ")
			if registerAccount(conn, username, password):
				print("Account created successfully")
                
		if login(conn, username, password) is False:
			print("Password is incorrect.")
		else:
			return username

"""
	Displays the character selection prompt.
	Users cannot have different characters with the same name.
	If the user inputs a character belonging to another user, that character will be linked to both users.
	Creates a new character if the given character name does not yet exist.
	Returns character name string
"""
def charSelect(conn, username):
	char_list = getCharList(conn, username)
	if len(char_list) > 0:
		print("Character List:\n \t" + "\n \t".join(char_list))

	charname = input("Enter character name: ")

	CHAR_NOT_EXISTS = 0
	CHAR_NOT_LINKED = 1
	CHAR_LINKED = 2

	char_status = checkChar(conn, username, charname)
	if char_status == CHAR_NOT_EXISTS:
		registerChar(conn, username, charname)
		print("New character '" + charname + "' created successfully")
	elif char_status == CHAR_NOT_LINKED:
		registerChar(conn, username, charname)
		print("Existing character '" + charname + "' linked successfully")
	elif char_status == CHAR_LINKED:
		print("Character: '" + charname + "'")

	return charname


"""
	Calculates and returns a character's attack and defense stat
"""
def getCombatStats(conn, charname):
	char_lv, char_gold, char_str, char_vit, char_hp = getCharStatus(conn, charname)

	char_atk = int(char_str + exptolv(char_lv) * 0.75)
	char_def = min(char_vit / 100, 0.8)

	return char_atk, char_def

"""
	Displays character level up prompt if necessary.
	Lets the user select which character stats to level up.

	Arguments:
		curr_exp -- (int) Character's current accumulated experience points
		added_exp -- (int) Experience points to be added to the character's

	Returns:
		new_exp -- (int) The character's updated experience points total
		inc_str -- (int) The value to increase character's strength by
		inc_vit -- (int) The value to increase character's vitality by
"""
def levelUp(curr_exp, added_exp):

	new_exp = curr_exp + added_exp
	inc_str = inc_vit = 0
	if exptolv(new_exp) > exptolv(curr_exp):
		num_new_lv = exptolv(new_exp) - exptolv(curr_exp)
		while num_new_lv > 0:
			action = input("Select a level up bonus:\n \t1. [s] strength\n \t2. [v] vitality\n")
			if action in ["1", "s"]:
				inc_str += 1
			elif action in ["2", "v"]:
				inc_vit += 1
			num_new_lv -= 1

	return new_exp, inc_str, inc_vit

"""
	Generates and initiates a dungeon instance.

	Randomly generates and selects enemies at each depth.
	Difficulty increases with depth.
	At every 10 depths, a boss monster is generated.
	Boss monsters are more difficult than regular monsters.
	Dungeon instance is automatically closed when the player is defeated or flees.
	The player may also choose to leave the dungeon after completing a depth.
	If the player is defeated, the player character is returned to town with 1 hp.
	The player will always keep all rewards from the dungeon.
	The character state will always be saved before returning.
"""
def enterDungeon(conn, charname, depth=0):
	depth = abs(int(depth))
	char_lv, char_gold, char_str, char_vit, char_hp = getCharStatus(conn, charname)
	char_atk, char_def = getCombatStats(conn, charname)

	while True:
		print("{} enters the dungeon at depth {}".format(charname, depth))
		if (depth + 1) % 10 != 0:
			monsters = [{"name": "slime", "level": (depth + 1) ** 2, "gold": 10, "exp": 5, "diff": 1},
						{"name": "zombie", "level": (depth + 1) ** 2, "gold": 50, "exp": 25, "diff": 5},
						{"name": "ogre", "level": (depth + 1) ** 2, "gold": 100, "exp": 100, "diff": 10}]
		else:
			monsters = [{"name": "wyvern", "level": (depth + 1) ** 2, "gold": 200, "exp": 100, "diff": 10},
						{"name": "undead dragon", "level": (depth + 1) ** 2, "gold": 400, "exp": 200, "diff": 20},
						{"name": "ancient dragon", "level": (depth + 1) ** 2, "gold": 500, "exp": 300, "diff": 30}]

		monster = monsters[random.randint(0, 2)]
		monster_hp = 10 + monster["level"] + monster["diff"]
		print("{name} encounters a level {level} {m_name}".format(name = charname,
																level = monster["level"],
																m_name = monster["name"]))

		players_turn = random.random()>=0.5
		while monster_hp > 0 and char_hp > 0:
			if players_turn:
				print("It's {name}'s turn".format(name=charname))
				action = input().split()
				if action[0] == "attack" or action[0] == "a":
					monster_hp -= char_atk
					print("{name} attacks the {m_name} for {dmg} damage".format(name = charname,
																			m_name = monster["name"],
																			dmg = char_atk))
				elif action[0] == "flee" or action[0] == "f":
					if random.random() >= 0.2:
						break
					else:
						dealt = monster["diff"] * char_def
						char_hp -= dealt
						print("The {name} failed to escape and was attacked by {m_name} for {dmg} damage".format(name = charname,
																											m_name = monster["name"],
																											dmg = dealt))
			else:
				dealt = monster["diff"] * char_def
				char_hp -= dealt
				print("The {m_name} attacks {name} for {dmg} damage".format(m_name = monster["name"],
																		name = charname,
																		dmg = dealt))
			players_turn = not players_turn

		if monster_hp <= 0:
			print("{name} defeated the {m_name} for {g} gold and {exp} experience".format(name = charname,
																					m_name = monster["name"],
																					g = monster["gold"],
																					exp = monster["exp"]))
			char_lv, inc_str, inc_vit = levelUp(char_lv, monster["exp"])
			char_gold += monster["gold"]
			char_str += inc_str
			char_vit += inc_vit
		elif char_hp <= 0:
			print("{name} was defeated by the {m_name} and barely escapes the dungeon".format(name = charname,
																							m_name = monster["name"]))
			char_hp = 1
			setCharStatus(conn, charname, char_lv, char_gold, char_str, char_vit, char_hp)
			return
		else:
			print("{name} leaves the dungeon".format(name = charname))
			return

		if input("Venture deeper into the dungeon? ([Y]/N)\n") in ["N", "n"]:
			print("{name} leaves the dungeon".format(name = charname))
			setCharStatus(conn, charname, char_lv, char_gold, char_str, char_vit, char_hp)
			return
		else:
			depth += 1


"""
	Main gameplay loop that continues until the user inputs the 'quit' command.
"""
def RPG(conn, charname):
	print("Welcome, {}, to DungeonTown\n *Type 'help' for commands".format(charname))

	while True:

		action = input("Enter an action: ").split()

		if action[0] == "help" or action[0] == "h":
			h = """
Available User Actions   Function
----------------------   --------
help/h                   Display actions available to user and functions
dungeon/d                
|
-> (#)                   Go to Dungeon, given a depth
status/c                 View status
equipment/el             View equipment
equip/e                  Equip item
|
-> (#)                   Equip item based on item key
unequip                  Unequip item
|
-> weapon/w              Unequip weapons
-> armor/ar              Unequip armors
-> accessory/ac          Unequip accessories
-> consumable/c          Unequip consumables
inventory/i              View entire inventory
|
-> weapon/w              View weapons
-> armor/ar              View armors
-> accessory/ac          View accessories
-> consumable/c          View consumables
use/u                    Use a consumable
shop/s                   View shop inventory
buy/b                    Buy items
sell/t                   Sell items
quit/q                   Quit session
"""
			print(h)

		elif action[0] == "dungeon" or action[0] == "d":
			arg = 0
			if len(action) > 1:
				arg = action[1]
			enterDungeon(conn, charname, depth=arg)
			print("Welcome back to DungeonTown\n *See help for commands")

		elif action[0] == "status" or action[0] == "c":
			showCharStatus(conn, charname)

		elif action[0] == "equipment" or action[0] == "el":
			showEquipment(conn, charname)

		elif action[0] == "equip" or action[0] == "e":
			if len(action) > 1:
				item_name = action[1]
				item_key = itemkey_from_name(conn, item_name)
				equipItem(conn, charname, item_key)
			else:
				print("Didn't specify item to equip")

		elif action[0] == "unequip":
			if len(action) > 1:
				arg = action[1]
				if arg == "weapon" or arg == "w":
					print("Unequip weapon...")
					unequipItem(conn, charname, weapon=True)
				if arg == "armor" or arg == "ar":
					print("Unequip armor...")
					unequipItem(conn, charname, armor=True)
				if arg == "accessory" or arg == "ac":
					print("Unequip accessory...")
					unequipItem(conn, charname, accessory=True)
				if arg == "consumable" or arg == "c":
					print("Unequip consumable...")
					unequipItem(conn, charname, consumable=True)
			else:
				print("Did not specify what to ")

		elif action[0] == "inventory" or action[0] == "i":
			if len(action) > 1:
				arg = action[1]
				if arg == "weapon" or arg == "w":
					getInventory(conn, charname, weapon=True)
				elif arg == "armor" or arg == "ar":
					getInventory(conn, charname, armor=True)
				elif arg == "accessory" or arg == "ac":
					getInventory(conn, charname, accessory=True)
				elif arg == "consumable" or arg == "c":
					getInventory(conn, charname, consumable=True)
			else:
				getInventory(conn, charname)
		
		elif action[0] == "use" or action[0] == "u":
			useConsumable(conn, charname)

		elif action[0] == "shop" or action[0] == "s":
			if len(action) == 1:
				print("usage: s [filter]\n \t filter \t(w)eapon, (ar)mor, (ac)cessory, or (c)onsumable")
			else:
				arg = action[1]
				if arg == "weapon" or arg == "w":
					getShopItems(conn, charname, weapon=True)
				if arg == "armor" or arg == "ar":
					getShopItems(conn, charname, armor=True)
				if arg == "accessory" or arg == "ac":
					getShopItems(conn, charname, accessory=True)
				if arg == "consumable" or arg == "c":
					getShopItems(conn, charname, consumable=True)

		elif action[0] == "buy" or action[0] == "b":
			if len(action) == 1:
				print("usage: b [item name] (quantity=1)")
			else:
				item_name = action[1]
				item_key = itemkey_from_name(conn, item_name)
				quantity = 1 if len(action) <= 2 else action[2]
				buyShopItem(conn, charname, item_key, quantity)


		elif action[0] == "sell" or action[0] == "t":
			if len(action) == 1:
				print("usage: s [item name] (quantity=1)")
			else:
				item_name = action[1]
				item_key = itemkey_from_name(conn, item_name)
				quantity = 1 if len(action) <= 2 else action[2]
				sellItem(conn, charname, item_key, quantity)


		elif action[0] in ["quit", "q"]:
			break
	print("Good bye {}".format(charname))

def main():
	database = r"RPG.sqlite"

	# create a database connection
	conn = openConnection(database)

	with conn:
		# Account login/creation
		username = loginPhase(conn)

		# Char selection process
		charname = charSelect(conn, username)

		# Begin game with selected character
		RPG(conn, charname)

	closeConnection(conn, database)


if __name__ == '__main__':
	main()
