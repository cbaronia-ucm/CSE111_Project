-- Drop Tables
-- =================================================
DROP TABLE player;
DROP TABLE character;
DROP TABLE playercharacter;
DROP TABLE equipment;
DROP TABLE inventory;
DROP TABLE item;
DROP TABLE inventoryitem;
DROP TABLE weapon;
DROP TABLE armor;
DROP TABLE accessory;
DROP TABLE consumable;
DROP TABLE shop;
DROP TABLE shopitem;

-- =================================================
-- *************************************************
-- =================================================


PRAGMA foreign_keys = ON;

-- Create Tables
-- =================================================
CREATE TABLE IF NOT EXISTS player (
	p_username VARCHAR(255) NOT NULL,
	p_password VARCHAR(255) NOT NULL,
	
	PRIMARY KEY(p_username)
);

CREATE TABLE IF NOT EXISTS character (
	c_charname VARCHAR(255) NOT NULL,
	c_level INTEGER(255) NOT NULL,
	c_gold INTEGER(255) NOT NULL,
	c_str INTEGER(255) NOT NULL,
	c_vit INTEGER(255) NOT NULL,
	c_hp INTEGER(255) NOT NULL,
	
	PRIMARY KEY(c_charname)
);

CREATE TABLE IF NOT EXISTS playercharacter (
	pc_username VARCHAR(255) NOT NULL,
	pc_charname VARCHAR(255) NOT NULL,
	
	PRIMARY KEY(pc_username, pc_charname)
);

CREATE TABLE IF NOT EXISTS equipment (
	e_charname VARCHAR(255) NOT NULL,
	e_weaponkey INTEGER(255) DEFAULT 0,
	e_armorkey INTEGER(255) DEFAULT 0,
	e_accessorykey INTEGER(255) DEFAULT 0,
	e_consumablekey INTEGER(255) DEFAULT 0
	
);

CREATE TABLE IF NOT EXISTS inventory (
	invt_charname VARCHAR(255) NOT NULL,
	invt_size INTEGER(255) NOT NULL
	
);

CREATE TABLE IF NOT EXISTS item (
	i_itemkey INTEGER(255) NOT NULL,
	i_name VARCHAR(255) NOT NULL,
	i_desc VARCHAR(255) NOT NULL,
	
	PRIMARY KEY(i_itemkey)
);

CREATE TABLE IF NOT EXISTS inventoryitem (
	invti_charname VARCHAR(255) NOT NULL,
	invti_itemkey INTEGER(255) NOT NULL,
	invti_quantity INTEGER(255) NOT NULL,
	
	PRIMARY KEY(invti_charname, invti_itemkey)
);

CREATE TABLE IF NOT EXISTS weapon (
	w_weaponkey INTEGER(255) NOT NULL,
	w_atk INTEGER(255) NOT NULL,
	
	PRIMARY KEY(w_weaponkey),
	CHECK (w_weaponkey >= 1 AND w_weaponkey <= 100)
);

CREATE TABLE IF NOT EXISTS armor (
	a_armorkey INTEGER(255) NOT NULL,
	a_def INTEGER(255) NOT NULL,
	
	PRIMARY KEY(a_armorkey),
	CHECK (a_armorkey >= 101 AND a_armorkey <= 200)
);

CREATE TABLE IF NOT EXISTS accessory (
	accs_accessorykey INTEGER(255) NOT NULL,
	accs_stat VARCHAR(255) NOT NULL,
	accs_rating INTEGER(255) NOT NULL,
	
	PRIMARY KEY(accs_accessorykey),
	CHECK (accs_accessorykey >= 201 AND accs_accessorykey <= 300),
	CHECK (accs_stat IN ('vit', 'str', 'hp'))
);

CREATE TABLE IF NOT EXISTS consumable (
	cns_consumablekey INTEGER(255) NOT NULL,
	cns_stat VARCHAR(255) NOT NULL,
	cns_rating INTEGER(255) NOT NULL,
	
	PRIMARY KEY(cns_consumablekey),
	CHECK (cns_consumablekey >= 301 AND cns_consumablekey <= 400),
	CHECK (cns_stat IN ('vit', 'str', 'hp', 'gold'))
);

CREATE TABLE IF NOT EXISTS shop (
	s_charname VARCHAR(255) NOT NULL,
	s_size INTEGER(255) NOT NULL
	
);

CREATE TABLE IF NOT EXISTS shopitem (
	si_charname VARCHAR(255) NOT NULL,
	si_itemkey INTEGER(255) NOT NULL,
	si_quantity INTEGER(255) NOT NULL,
	si_buy INTEGER(255) NOT NULL,
	si_sell INTEGER(255) NOT NULL
	
);

-- =================================================
-- *************************************************
-- =================================================

-- Create Triggers, if needed
-- =================================================

-- Equip Item
--     Update character 

-- Unequip Item
--     Update character & equipment

-- Use Consumable
--     Update character & equipment 

-- Buy Item
--     Check character has enough gold and inventory space
--     If so, update character and inventoryitem

-- Sell Item
--     Check character has item in inventory
--     If so, update/delete from character, inventoryitem, equipment

-- =================================================
-- *************************************************
-- =================================================

-- Load Sample Data
-- =================================================

.mode "csv"
.separator ","
.headers off

.import 'Sample_Data/Accessory.csv' accessory
.import 'Sample_Data/Armor.csv' armor
.import 'Sample_Data/Character.csv' character
.import 'Sample_Data/Consumable.csv' consumable
.import 'Sample_Data/Equipment.csv' equipment
.import 'Sample_Data/Inventory.csv' inventory
.import 'Sample_Data/InventoryItem.csv' inventoryitem
.import 'Sample_Data/Item.csv' item
.import 'Sample_Data/Player.csv' player
.import 'Sample_Data/PlayerCharacter.csv' playercharacter
.import 'Sample_Data/Shop.csv' shop
.import 'Sample_Data/ShopItem.csv' shopitem
.import 'Sample_Data/Weapon.csv' weapon
