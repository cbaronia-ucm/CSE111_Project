import sqlite3
from sqlite3 import Error

def openConnection(_dbFile):
	print("++++++++++++++++++++++++++++++++++")
	print("Open database: ", _dbFile)

	conn = None
	try:
		conn = sqlite3.connect(_dbFile)
		print("success")
	except Error as e:
		print(e)

	print("++++++++++++++++++++++++++++++++++")

	return conn

def closeConnection(conn, _dbFile):
	print("++++++++++++++++++++++++++++++++++")
	print("Close database: ", _dbFile)

	try:
		conn.close()
		print("success")
	except Error as e:
		print(e)

	print("++++++++++++++++++++++++++++++++++")

###############################################################################
###                              User Accounts                              ###
###############################################################################

# Adds a new user account
def registerAccount(conn, username, password):
	sql = "INSERT INTO player VALUES ('{}', '{}');".format(username, password)
	crsr = conn.cursor()
	crsr.execute(sql)

# Returns True when there exists an account with the given credentials, else False
def login(conn, username, password):
	sql = "SELECT * FROM player WHERE p_username = '{}' and p_password = '{}';".format(username, password)
	crsr = conn.cursor()
	crsr.execute(sql)
	res = crsr.fetchall()
	return len(res) > 0

# Returns True when there exists an account with the given username, else False
def checkUser(conn, username):
	sql = "SELECT * FROM player WHERE p_username = '{}';".format(username)
	crsr = conn.cursor()
	crsr.execute(sql)
	res = crsr.fetchall()
	return len(res) > 0

###############################################################################
###                              Characters                                 ###
###############################################################################

# Returns List of character names associated with the given user
def getCharList(conn, username):
	sql = "SELECT pc_charname FROM playercharacter WHERE pc_username = '{}';".format(username)
	crsr = conn.cursor()
	crsr.execute(sql)
	res = crsr.fetchall()
	return [row[0] for row in res]

# Checks if the user has the given character
def checkChar(conn, username, charname):
	CHAR_NOT_EXISTS = 0
	CHAR_NOT_LINKED = 1
	CHAR_LINKED = 2

	sql = "SELECT pc_username FROM playercharacter WHERE pc_charname = '{}';".format(charname)
	crsr = conn.cursor()
	crsr.execute(sql)
	res = crsr.fetchall()

	if username in [row[0] for row in res]:
		return CHAR_LINKED
	elif len(res) > 0:
		return CHAR_NOT_LINKED
	else:
		return CHAR_NOT_EXISTS

# Associates a character to the given user, also creating a new character if needed
def registerChar(conn, username, charname):
	sql = "INSERT INTO playercharacter \
			SELECT '{u}', '{c}' \
			EXCEPT \
			SELECT pc_username, pc_charname \
			FROM playercharacter \
			WHERE pc_username = '{u}' \
				AND pc_charname = '{c}'; ".format(u = username, c = charname)
	sql += "INSERT INTO character \
			SELECT '{c}', 0, 200, 10, 10, 100 \
			EXCEPT \
			SELECT c_charname, 0, 200, 10, 10, 100 \
			FROM character \
			WHERE c_charname = '{c}';".format(c = charname)

	crsr = conn.cursor()
	crsr.executescript(sql)

# Returns the level, gold, str, vit, and hp of the given character
def getCharStatus(conn, charname):
	sql = "SELECT * FROM character WHERE c_charname = '{}';".format(charname)
	crsr = conn.cursor()
	crsr.execute(sql)
	res = crsr.fetchall()
	stats =  res[0][1:]
	return stats

"""
	Returns whole level(s) calculated from total accumulated experience points
"""
def exptolv(raw_points):
	return int(raw_points / 100)

def showCharStatus(conn, charname):
	sql = "SELECT * FROM character WHERE c_charname = '{}';".format(charname)
	crsr = conn.cursor()
	crsr.execute(sql)
	res = crsr.fetchall()
	level, gold, strength, vitality, hp = res[0][1:]
	print("Character: {}".format(charname))
	l = "Level: {} \t Gold: {}".format(exptolv(level), gold)
	print(l)
	l = "STR: {} \t VIT: {} \t HP: {}".format(strength, vitality, hp)
	print(l)

# Change the stats of the given character
def setCharStatus(conn, charname, level, gold, str, vit, hp):
	sql = "UPDATE character \
			SET c_level = {}, \
				c_gold = {}, \
				c_str = {}, \
				c_vit = {}, \
				c_hp =  {} \
			WHERE c_charname = '{}';".format(level, gold, str, vit, hp, charname)
	crsr = conn.cursor()
	crsr.execute(sql)

###############################################################################
###                               Equipment                                 ###
###############################################################################

# Return character's equipment
def getEquipment(conn, charname):
	sql = """SELECT i_name
			FROM equipment, item
			WHERE
				e_charname = ? AND
				(e_weaponkey = i_itemkey OR
				e_armorkey = i_itemkey OR
				e_accessorykey = i_itemkey OR
				e_consumablekey = i_itemkey OR);"""
	args = [charname]

	cur = conn.cursor()
	cur.execute(sql, args)

# Print character's equipment
def showEquipment(conn, charname):
	sql = """SELECT i_itemkey, i_name
			FROM equipment, item
			WHERE
				e_charname = ? AND
				(e_weaponkey = i_itemkey OR
				e_armorkey = i_itemkey OR
				e_accessorykey = i_itemkey OR
				e_consumablekey = i_itemkey);"""
	args = [charname]

	cur = conn.cursor()
	cur.execute(sql, args)

	rows = cur.fetchall()

	for row in rows:
		if(row[0] >= 1 and row[0] <= 100):
			l = "Weapon: {}".format(row[1])
			print (l)
		elif(row[0] >= 101 and row[0] <= 200):
			l = "Armor: {}".format(row[1])
			print (l)
		elif(row[0] >= 201 and row[0] <= 300):
			l = "Accessory: {}".format(row[1])
			print (l)
		elif(row[0] >= 301 and row[0] <= 400):
			l = "Consumable: {}".format(row[1])
			print (l)
		

# Equip an item to character
#     Check item is available in inventory (Database)
#     If so, update character status and equipment
#     If not, print message indicating item not in inventory
def equipItem(conn, charname, itemkey):

	# Check item is in inventory
	sql = """SELECT invti_itemkey FROM inventoryitem WHERE invti_charname = ? AND invti_itemkey = ?"""
	args = [charname, itemkey]

	cur = conn.cursor()
	cur.execute(sql, args)

	res = cur.fetchone()

	# If in inventory, carry on, if not, leave
	if res != None:
		print("Equipping item...")
		pass
	else:
		print("Item not in inventory")
		return
	
	# Check item type and update accordingly
	if int(itemkey) >= 1 and int(itemkey) <= 100:
		sql = """UPDATE equipment
				SET e_weaponkey = ?
				WHERE e_charname = ?"""
	elif int(itemkey) >= 101 and int(itemkey) <= 200:
		sql = """UPDATE equipment
				SET e_armorkey = ?
				WHERE e_charname = ?"""
	elif int(itemkey) >= 201 and int(itemkey) <= 300:
		sql = """UPDATE equipment
				SET e_accessorykey = ?
				WHERE e_charname = ?"""
	elif int(itemkey) >= 301 and int(itemkey) <= 400:
		sql = """UPDATE equipment
				SET e_consumablekey = ?
				WHERE e_charname = ?"""
	else:
		print("Invalid item key")
		return

	args = [itemkey, charname]

	cur = conn.cursor()
	cur.execute(sql, args)

	conn.commit()

# Unequip item on character
def unequipItem(conn, charname, weapon=False, armor=False, accessory=False, consumable=False):

	# Check item type and update accordingly
	if weapon:
		sql = """UPDATE equipment
				SET e_weaponkey = 0
				WHERE e_charname = ?"""
	if armor:
		sql = """UPDATE equipment
				SET e_armorkey = 0
				WHERE e_charname = ?"""
	if accessory:
		sql = """UPDATE equipment
				SET e_accessorykey = 0
				WHERE e_charname = ?"""
	if consumable:
		sql = """UPDATE equipment
				SET e_consumablekey = 0
				WHERE e_charname = ?"""

	args = [charname]

	cur = conn.cursor()
	cur.execute(sql, args)

	conn.commit()

# Character uses equipped consumable item
def useConsumable(conn, charname):
	
	# Check consumable item is equipped
	sql = """SELECT e_consumablekey FROM equipment WHERE e_charname = ? AND e_consumablekey > 0"""
	args = [charname]

	cur = conn.cursor()
	cur.execute(sql, args)

	res = cur.fetchone()

	# If equipped, carry on, if not, leave
	if res != None:
		print("Using item...")
		pass
	else:
		print("Item not equipped")
		return
	
	# Update inventoryitem quantity (Decrement by 1)
	sql = """UPDATE inventoryitem
			SET invti_quantity = invti_quantity - 1
			WHERE
				invti_charname = ? AND
				invti_itemkey = (SELECT e_consumablekey 
								FROM equipment
								WHERE 
									e_charname = ?)"""
	
	args = [charname, charname]

	cur = conn.cursor()
	cur.execute(sql, args)

	# Check if inventoryitem quantity reached <=0
	# If so, unequip item and delete item from inventoryitem
	sql = """DELETE FROM inventoryitem
			WHERE 
			invti_charname = ? AND
			invti_itemkey = (SELECT e_consumablekey 
								FROM equipment
								WHERE 
									e_charname = ?) AND
			invti_quantity <= 0"""
	
	args = [charname, charname]

	cur = conn.cursor()
	cur.execute(sql, args)

	conn.commit()


###############################################################################
###                               Game Items                                ###
###############################################################################
def getItemList(conn, weapon=False, armor=False, accessory=False, consumable=False):
	if weapon:
		sql = "SELECT i_name, w_atk, i_desc \
			FROM item, weapon \
			WHERE  \
				i_itemkey = w_weaponkey;"
	elif armor:
		sql = "SELECT i_name, a_def, i_desc \
			FROM item, armor \
			WHERE  \
				i_itemkey = a_armorkey;"
	elif accessory:
		sql = "SELECT i_name, accs_stat, accs_rating, i_desc \
			FROM item, accessory \
			WHERE  \
				i_itemkey = accs_accessorykey;"
	elif consumable:
		sql = "SELECT i_name, cns_stat, cns_rating, i_desc \
			FROM item, consumable \
			WHERE  \
				i_itemkey = cns_consumablekey;"
	crsr = conn.cursor()
	crsr.execute(sql)
	res = crsr.fetchall()
	if weapon:
		for name, atk, desc in res:
			l = "{:20} {:20} {:20}".format(name, atk, desc)
			print(l)
	elif armor:
		for name, defense, desc in res:
			l = "{:20} {:20} {:20}".format(name, defense, desc)
			print(l)
	elif accessory:
		for name, stat, rating, desc in res:
			l = "{:20} {:20} {:20} {:20}".format(name, stat, rating, desc)
			print(l)
	elif consumable:
		for name, stat, rating, desc in res:
			l = "{:20} {:20} {:20} {:20}".format(name, stat, rating, desc)
			print(l)
	return res

###############################################################################
###                               Inventory                                 ###
###############################################################################

def getInventory(conn, charname, weapon=False, armor=False, accessory=False, consumable=False):
	if weapon:
		table = "weapon"
		p_key = "w_weaponkey"
	elif armor:
		table = "armor"
		p_key = "a_armorkey"
	elif accessory:
		table = "accessory"
		p_key = "accs_accessorykey"
	elif consumable:
		table = "consumable"
		p_key = "cns_consumablekey"
	if weapon|armor|accessory|consumable:
		sql = "SELECT i_name, invti_quantity \
				FROM \
					inventory, \
					inventoryitem, \
					item, \
					{} \
				WHERE \
					invt_charname = '{}' AND \
					invt_charname = invti_charname AND \
					invti_itemkey = i_itemkey AND \
					i_itemkey = {};".format(table, charname, p_key)
	else:
		sql = "SELECT i_name, invti_quantity \
				FROM \
					inventory, \
					inventoryitem, \
					item \
				WHERE \
					invt_charname = '{}' AND \
					invt_charname = invti_charname AND \
					invti_itemkey = i_itemkey;".format(charname)
	crsr = conn.cursor()
	crsr.execute(sql)
	res = crsr.fetchall()
	for name, quantity in res:
		l = "{}x {}".format(quantity, name)
		print(l)
	return res

def itemkey_from_name(conn, item_name):
	sql = "SELECT i_itemkey \
			FROM item \
			WHERE i_name = '{}';".format(item_name)
	crsr = conn.cursor()
	crsr.execute(sql)
	res = crsr.fetchall()
	return res[0][0]

###############################################################################
###                                  Shop                                   ###
###############################################################################

def getShopItems(conn, charname, weapon=False, armor=False, accessory=False, consumable=False):
	if weapon:
		table = "weapon"
		p_key = "w_weaponkey"
		sql = "SELECT i_name, w_atk, si_quantity, si_buy \
			FROM \
				shop, \
				shopitem, \
				item, \
				{} \
			WHERE \
				s_charname = '{}' AND \
				s_charname = si_charname AND \
				si_itemkey = i_itemkey AND \
				i_itemkey = {};".format(table, charname, p_key)
		crsr = conn.cursor()
		crsr.execute(sql)
		res = crsr.fetchall()
		for name, atk, quantity, price in res:
			l = "{:>7}x {} {} ATK \t {} gold".format(quantity, name, atk, price)
			if quantity > 0:
				print(l)
	elif armor:
		table = "armor"
		p_key = "a_armorkey"
		sql = "SELECT i_name, a_def, si_quantity, si_buy \
			FROM \
				shop, \
				shopitem, \
				item, \
				{} \
			WHERE \
				s_charname = '{}' AND \
				s_charname = si_charname AND \
				si_itemkey = i_itemkey AND \
				i_itemkey = {};".format(table, charname, p_key)
		crsr = conn.cursor()
		crsr.execute(sql)
		res = crsr.fetchall()
		for name, defense, quantity, price in res:
			l = "{:>7}x {} {} DEF \t {} gold".format(quantity, name, defense, price)
			if quantity > 0:
				print(l)
	elif accessory:
		table = "accessory"
		p_key = "accs_accessorykey"
		sql = "SELECT i_name, accs_stat, accs_rating, si_quantity, si_buy \
			FROM \
				shop, \
				shopitem, \
				item, \
				{} \
			WHERE \
				s_charname = '{}' AND \
				s_charname = si_charname AND \
				si_itemkey = i_itemkey AND \
				i_itemkey = {};".format(table, charname, p_key)
		crsr = conn.cursor()
		crsr.execute(sql)
		res = crsr.fetchall()
		for name, stat, rate, quantity, price in res:
			l = "{:>7}x {} {} {} \t {} gold".format(quantity, name, rate, stat, price)
			if quantity > 0:
				print(l)
	elif consumable:
		table = "consumable"
		p_key = "cns_consumablekey"
		sql = "SELECT i_name, cns_stat, cns_rating, si_quantity, si_buy \
			FROM \
				shop, \
				shopitem, \
				item, \
				{} \
			WHERE \
				s_charname = '{}' AND \
				s_charname = si_charname AND \
				si_itemkey = i_itemkey AND \
				i_itemkey = {};".format(table, charname, p_key)
		crsr = conn.cursor()
		crsr.execute(sql)
		res = crsr.fetchall()
		for name, stat, rate, quantity, price in res:
			l = "{:>7}x {} {} {} \t {} gold".format(quantity, name, rate, stat, price)
			if quantity > 0:
				print(l)
	else:
		sql = "SELECT i_name, si_quantity, si_buy, i_itemkey \
			FROM \
				shop, \
				shopitem, \
				item \
			WHERE \
				s_charname = '{}' AND \
				s_charname = si_charname AND \
				si_itemkey = i_itemkey;".format(charname)
		crsr = conn.cursor()
		crsr.execute(sql)
		res = crsr.fetchall()
		for name, quantity, price, _ in res:
			l = "{:>7}x {} \t {} gold".format(quantity, name, price)
			if quantity > 0:
				print(l)
	return res

def buyShopItem(conn, charname, itemkey, quantity):
	sql = "UPDATE shopitem \
			SET si_quantity = ( \
				SELECT si_quantity - {q} \
				FROM shopitem \
				WHERE si_charname = '{name}' \
					AND si_itemkey = {k}) \
			WHERE \
				si_charname = '{name}' AND \
				si_itemkey = {k}; \
 \
			UPDATE inventoryitem \
			SET invti_quantity = ( \
				SELECT invti_quantity + {q} \
				FROM inventoryitem \
				WHERE invti_charname = '{name}' \
					AND invti_itemkey = {k}) \
			WHERE \
				invti_charname = '{name}' AND \
				invti_itemkey = {k}; \
 \
			UPDATE character \
			SET c_gold = ( \
				SELECT c_gold - {q} * (SELECT si_buy \
									FROM shopitem \
									WHERE si_charname = '{name}' \
										AND si_itemkey = {k}) \
				FROM character \
				WHERE c_charname = '{name}') \
			WHERE \
				c_charname = '{name}';".format(q=quantity, k=itemkey, name=charname)
	crsr = conn.cursor()
	try:
		crsr.executescript(sql)
	except Exception as e:
		print(e)
		return False
	sql = "SELECT i_name \
		FROM item \
		WHERE i_itemkey = {};".format(itemkey)
	sql = "SELECT i_name, si_buy \
		FROM item, shopitem \
		WHERE i_itemkey = si_itemkey \
			AND i_itemkey = {};".format(itemkey)
	crsr.execute(sql)
	i_name, si_buy = crsr.fetchall()[0]
	print("{} bought {}x {} for {} gold".format(charname, quantity, i_name, int(quantity) * int(si_buy)))
	return True # returns True if buy succeeds, else False

def sellItem(conn, charname, itemkey, quantity):
	sql = "UPDATE shopitem \
			SET si_quantity = ( \
				SELECT si_quantity + {q} \
				FROM shopitem \
				WHERE si_charname = '{name}' \
					AND si_itemkey = {k}) \
			WHERE \
				si_charname = '{name}' AND \
				si_itemkey = {k}; \
 \
			UPDATE inventoryitem \
			SET invti_quantity = ( \
				SELECT invti_quantity - {q} \
				FROM inventoryitem \
				WHERE invti_charname = '{name}' \
					AND invti_itemkey = {k}) \
			WHERE \
				invti_charname = '{name}' AND \
				invti_itemkey = {k}; \
 \
			DELETE FROM inventoryitem \
			WHERE invti_quantity <= 0; \
\
			UPDATE character \
			SET c_gold = ( \
				SELECT c_gold + {q} * (SELECT si_sell \
									FROM shopitem \
									WHERE si_charname = '{name}' \
										AND si_itemkey = {k}) \
				FROM character \
				WHERE c_charname = '{name}') \
			WHERE \
				c_charname = '{name}';".format(q=quantity, k=itemkey, name=charname)
	crsr = conn.cursor()
	try:
		crsr.executescript(sql)
	except Exception as e:
		print(e)
		return False
	sql = "SELECT i_name, si_sell \
		FROM item, shopitem \
		WHERE i_itemkey = si_itemkey \
			AND i_itemkey = {};".format(itemkey)
	crsr.execute(sql)
	name, sell = crsr.fetchall()[0]
	print("{} sold {}x {} for {} gold".format(charname, quantity, name, int(quantity) * int(sell)))
	return True # returns True if sell succeeds, else False